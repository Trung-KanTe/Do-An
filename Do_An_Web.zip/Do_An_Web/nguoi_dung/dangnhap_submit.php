<html>
	<body>
	<?php
    include_once '../giao_dien/cau_hinh.php';
	// Lấy thông tin từ FORM
		$TenTaiKhoan = $_POST['txt_TK'];
		$MatKhau = $_POST['txt_MK'];
		$_SESSION['Loi_Dang_Nhap'] = 1;
		$sql_kiemtra = "SELECT * FROM tai_khoan WHERE TenTaiKhoan = '$TenTaiKhoan' AND MatKhau = '$MatKhau'";				
		
		$danhsach = $connect->query($sql_kiemtra);
		//Nếu kết quả kết nối không được thì xuất báo lỗi và thoát
		if (!$danhsach) {
			die("Không thể thực hiện câu lệnh SQL: " . $connect->connect_error);
			exit();
		}
		
		$dong = $danhsach->fetch_array(MYSQLI_ASSOC);
		if($dong)
		{
			// Đăng ký SESSION
			$_SESSION['HoNguoiDung'] = $dong['HoNguoiDung'];
			$_SESSION['TenNguoiDung'] = $dong['TenNguoiDung'];
			$_SESSION['KiTuTen'] = substr($_SESSION['TenNguoiDung'], 0, 1);
			$_SESSION['QuyenHan'] = $dong['QuyenHan'];
				// Chuyển hướng về trang index.php
			Header("Location:../giao_dien/quan_li.php");
		}
		else
		{	
			$_SESSION['loi_dang_nhap'] = 1;
			Header("Location:../giao_dien/index.php");
		}			
		
	?>	
	
	

				
	</body>
</html>

