<?php
    include_once '../giao_dien/cau_hinh.php';

    $Ho = $_POST['txt_Ho'];
	$Ten = $_POST['txt_Ten'];
    $SDT = $_POST['txt_SDT'];
    $Email = $_POST['txt_Email'];
    $TenTaiKhoan = $_POST['txt_TK'];
    $MatKhau = $_POST['txt_MK'];

    $sql = "insert into `tai_khoan` (`HoNguoiDung`,`TenNguoiDung`, `SoDienThoai`, `Email`, `TenTaiKhoan`, `MatKhau`, `QuyenHan`)
		        VALUES ('$Ho', '$Ten', '$SDT', '$Email', '$TenTaiKhoan', '$MatKhau', 1)";
		if ($connect->query($sql) === TRUE)
		{   
			header("Location: ../giao_dien/index.php");
            $_SESSION['dangky_thanhcong'] = 'Đăng ký thành công!!!';
		}
		else
		{
			echo "Lỗi: " . $sql . "<br>" . $connect->error;
		}
		$connect->close();

?>