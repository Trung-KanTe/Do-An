<html>
	<header>
		<link rel="stylesheet" href="../css/giao_dien_form_dang_nhap.css">
		<link rel="stylesheet" href="../css/mau_va_kieuchu.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" integrity="sha512-Avb2QiuDEEvB4bZJYdft2mNjVShBftLdPG8FJ0V7irTLQ8Uo0qcPxh4Plq7G5tGm0rU+1SPhVotteLpBERwTkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

	</header>
	<body>	
	<div class="thong_bao">
            
	</div>
	<form class="form_dang_ky_dang_nhap" action="../nguoi_dung/dangnhap_submit.php" method="POST" onsubmit="return submit_form();" >
		<div class="khung_chua">
			<div class="tieu_De">
				<p class="ten_the">Đăng nhập</p>
				<i id="icon" class="fa-solid fa-xmark" onclick="tat_form()"></i>
			</div>
			<div class="groupbox_100">
				<label for="txt_TK">Tên tài khoản<br></label>
				<input type="text" name="txt_TK" id="txt_TK" class="text_box" placeholder="Tên tài khoản" onblur="thong_bao_sai_ten_tai_khoan()">
				<span class="loi" id="loi_TK">	

				</span>
			</div>
			<div class="groupbox_100" >
				<label for="txt_MK">Mật khẩu<br></label>
				<input type="password" name="txt_MK" id="txt_MK" class="text_box" placeholder="Mật khẩu" onblur="thong_bao_chua_nhap_mat_khau()">
                <i class="fa-solid fa-eye hien_mat_khau"></i>
                <span class="loi" id="loi_MK"></span>			
            </div>
			<button class="nut_dang_ky" type="submit">Đăng nhập</button>
		</div>
		
	</form>	

	<script>
		function tat_form(){
			document.location.href = '../giao_dien/index.php';
		}

		function thong_bao_sai_ten_tai_khoan(){
			let TK = document.getElementById('txt_TK').value;
			let chuoi = "";
			let Loi_TK = document.getElementById('loi_TK');
			if (TK.trim() == ""){
				chuoi = "Tên tài khoản không được để trống";
			}else{
				chuoi = "";
			}
			Loi_TK.innerHTML = chuoi;
			return chuoi;
		}
		function thong_bao_chua_nhap_mat_khau(){
			let chuoi = "";
			let MatKhau = document.getElementById('txt_MK').value;
			let Loi_MK = document.getElementById('loi_MK');
			if (MatKhau.trim() == ""){
				chuoi = "Mật khẩu không được để trống";
			}else{
				chuoi = "";
			}
			Loi_MK.innerHTML = chuoi;
			return chuoi;
		}
		
		function submit_form(){
			let Loi_Ten = document.getElementById('loi_ten_dang_nhap');
			let Loi_SDT = document.getElementById('loi_SDT');
			let Loi_Email = document.getElementById('loi_Email');
			let Loi_TK = document.getElementById('loi_TK');
			let Loi_MK = document.getElementById('loi_MK');
			let Loi_XNMK = document.getElementById('loi_XNMK');

			if (thong_bao_sai_ten_tai_khoan() || thong_bao_chua_nhap_mat_khau()){
				Loi_TK.innerHTML = thong_bao_sai_ten_tai_khoan();
				Loi_MK.innerHTML = thong_bao_chua_nhap_mat_khau();
				return false;
			}
		}
        function an_hien_mat_khau(){
			let nhan_Mat_Khau = document.getElementsByClassName('hien_mat_khau');
			let MatKhau = document.getElementById('txt_MK');
			nhan_Mat_Khau[0].addEventListener('click', function(){
				nhan_Mat_Khau[0].style.opacity = (nhan_Mat_Khau[0].style.opacity === "1") ? "0.5" : "1";
				MatKhau.type = (MatKhau.type === "text") ? "password" : "text";
			});
		}
		an_hien_mat_khau();
	</script>
	
	</body>
</html>