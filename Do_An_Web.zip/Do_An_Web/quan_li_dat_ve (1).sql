-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2023 at 01:51 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quan_li_dat_ve`
--

-- --------------------------------------------------------

--
-- Table structure for table `lichchieu`
--

CREATE TABLE `lichchieu` (
  `MaLichChieu` int(255) NOT NULL,
  `MaPhim` varchar(11) NOT NULL,
  `LichChieu` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lichchieu`
--

INSERT INTO `lichchieu` (`MaLichChieu`, `MaPhim`, `LichChieu`) VALUES
(1, 'HD001', '9:00 - 11:00'),
(2, 'HD001', '13:00 - 15:00'),
(3, 'TL001', '9:00 - 11:00'),
(4, 'TL001', '15:00 - 17:00'),
(5, 'HD002', '9:00 - 11:00'),
(6, 'HD002', '15:00 - 17:00'),
(7, 'KD001', '9:00 - 11:00'),
(8, 'KD001', '11:00 - 13:00'),
(9, 'KD001', '15:00 - 17:00'),
(11, 'TL001', '15:00 - 17:00'),
(12, 'TL001', '17:00 - 19:00'),
(13, 'TL002', '11:00 - 13:00'),
(14, 'TL002', '15:00 - 17:00'),
(15, 'HH001', '11:00 - 13:00'),
(16, 'HH001', '15:00 - 17:00'),
(17, 'HH001', '17:00 - 19:00');

-- --------------------------------------------------------

--
-- Table structure for table `phim`
--

CREATE TABLE `phim` (
  `MaPhim` char(5) NOT NULL,
  `TenPhim` varchar(255) NOT NULL,
  `TheLoai` varchar(255) NOT NULL,
  `HinhAnh` tinytext NOT NULL,
  `GiaVe` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `phim`
--

INSERT INTO `phim` (`MaPhim`, `TenPhim`, `TheLoai`, `HinhAnh`, `GiaVe`) VALUES
('HD001', 'BIỆT ĐỘI SIÊU ANH HÙNG', 'Hành động Khoa học viễn tưởng\r\n', 'Biet_Doi_Marvel.jpg', 150000),
('HD002', 'NGƯỜI VỢ CUỐI CÙNG', 'Hành động Tâm lý Lãng mạn ', 'Nguoi_Vo_Cuoi_Cung.jpg', 100000),
('HH001', 'CHỊ MƯỜI BA', 'Hành động Hài hước ', 'chi_muoi_b.jpg', 100000),
('KD001', 'QUẢ TIM MÁU', 'Hành động Kinh dị Võ thuật ', 'qua_tim_mau.jpg', 150000),
('TL001', 'CẬU VÀNG', 'Tâm lý Tài liệu ', 'cau_vang.jpg', 100000),
('TL002', 'TẤM CÁM', 'Tâm lý Lãng mạn ', 'tfam_cam.jpg', 100000);

-- --------------------------------------------------------

--
-- Table structure for table `tai_khoan`
--

CREATE TABLE `tai_khoan` (
  `MaKhachHang` int(11) NOT NULL,
  `HoNguoiDung` varchar(10) NOT NULL,
  `TenNguoiDung` varchar(32) NOT NULL,
  `SoDienThoai` varchar(11) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `TenTaiKhoan` varchar(50) NOT NULL,
  `MatKhau` varchar(20) NOT NULL,
  `QuyenHan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tai_khoan`
--

INSERT INTO `tai_khoan` (`MaKhachHang`, `HoNguoiDung`, `TenNguoiDung`, `SoDienThoai`, `Email`, `TenTaiKhoan`, `MatKhau`, `QuyenHan`) VALUES
(15, 'Võ', 'Nghi', '0797028194', 'nghi@gmail.com', 'xxihgn', 'Nghi2003', 1),
(16, 'Võ', 'Phong', '0867574607', 'thanhphong@gmail.com', 'thanhphong', 'Nghi2003', 2),
(17, 'Nguyễn', 'Trung', '0987654321', 'trung@gmail.com', 'nguyentrung', '123456', 1),
(18, 'Cao', 'Thảo', '0123456789', 'thao@gmail.com', 'thao', '12345', 1),
(19, 'Võ Thanh', 'Phong', '0987654321', 'thanhphong@gmil.com', 'thanhphong11', '12345', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ve`
--

CREATE TABLE `ve` (
  `MaVe` int(255) NOT NULL,
  `TenVe` varchar(20) NOT NULL,
  `MaLichChieu` int(255) NOT NULL,
  `HienTrang` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ve`
--

INSERT INTO `ve` (`MaVe`, `TenVe`, `MaLichChieu`, `HienTrang`) VALUES
(1, '1', 1, NULL),
(2, '2', 1, NULL),
(3, '3', 1, NULL),
(4, '4', 1, NULL),
(5, '5', 1, NULL),
(6, '6', 1, NULL),
(7, '7', 1, NULL),
(8, '8', 1, NULL),
(9, '9', 1, NULL),
(10, '10', 1, NULL),
(11, '11', 1, NULL),
(12, '12', 1, NULL),
(13, '13', 1, NULL),
(14, '14', 1, NULL),
(15, '15', 1, NULL),
(16, '16', 1, NULL),
(17, '17', 1, NULL),
(18, '18', 1, NULL),
(19, '19', 1, NULL),
(20, '20', 1, NULL),
(21, '21', 1, NULL),
(22, '22', 1, NULL),
(23, '23', 1, NULL),
(24, '24', 1, NULL),
(25, '25', 1, NULL),
(26, '26', 1, NULL),
(27, '27', 1, NULL),
(28, '28', 1, NULL),
(29, '29', 1, NULL),
(30, '30', 1, NULL),
(31, '1', 2, NULL),
(32, '2', 2, NULL),
(33, '3', 2, NULL),
(34, '4', 2, NULL),
(35, '5', 2, NULL),
(36, '6', 2, NULL),
(37, '7', 2, NULL),
(38, '8', 2, NULL),
(39, '9', 2, NULL),
(40, '10', 2, NULL),
(41, '11', 2, NULL),
(42, '12', 2, NULL),
(43, '13', 2, NULL),
(44, '14', 2, NULL),
(45, '15', 2, NULL),
(46, '16', 2, NULL),
(47, '17', 2, NULL),
(48, '18', 2, NULL),
(49, '19', 2, NULL),
(50, '20', 2, NULL),
(51, '21', 2, NULL),
(52, '22', 2, NULL),
(53, '23', 2, NULL),
(54, '24', 2, NULL),
(55, '25', 2, NULL),
(56, '26', 2, NULL),
(57, '27', 2, NULL),
(58, '28', 2, NULL),
(59, '29', 2, NULL),
(60, '30', 2, NULL),
(61, '1', 3, NULL),
(62, '2', 3, NULL),
(63, '3', 3, NULL),
(64, '4', 3, NULL),
(65, '5', 3, NULL),
(66, '6', 3, NULL),
(67, '7', 3, NULL),
(68, '8', 3, NULL),
(69, '9', 3, NULL),
(70, '10', 3, NULL),
(71, '11', 3, NULL),
(72, '12', 3, NULL),
(73, '13', 3, NULL),
(74, '14', 3, NULL),
(75, '15', 3, NULL),
(76, '16', 3, NULL),
(77, '17', 3, NULL),
(78, '18', 3, NULL),
(79, '19', 3, NULL),
(80, '20', 3, NULL),
(81, '21', 3, NULL),
(82, '22', 3, NULL),
(83, '23', 3, NULL),
(84, '24', 3, NULL),
(85, '25', 3, NULL),
(86, '26', 3, NULL),
(87, '27', 3, NULL),
(88, '28', 3, NULL),
(89, '29', 3, NULL),
(90, '30', 3, NULL),
(91, '1', 4, NULL),
(92, '2', 4, NULL),
(93, '3', 4, NULL),
(94, '4', 4, NULL),
(95, '5', 4, NULL),
(96, '6', 4, NULL),
(97, '7', 4, NULL),
(98, '8', 4, NULL),
(99, '9', 4, NULL),
(100, '10', 4, NULL),
(101, '11', 4, NULL),
(102, '12', 4, NULL),
(103, '13', 4, NULL),
(104, '14', 4, NULL),
(105, '15', 4, NULL),
(106, '16', 4, NULL),
(107, '17', 4, NULL),
(108, '18', 4, NULL),
(109, '19', 4, NULL),
(110, '20', 4, NULL),
(111, '21', 4, NULL),
(112, '22', 4, NULL),
(113, '23', 4, NULL),
(114, '24', 4, NULL),
(115, '25', 4, NULL),
(116, '26', 4, NULL),
(117, '27', 4, NULL),
(118, '28', 4, NULL),
(119, '29', 4, NULL),
(120, '30', 4, NULL),
(121, '1', 5, NULL),
(122, '2', 5, NULL),
(123, '3', 5, NULL),
(124, '4', 5, NULL),
(125, '5', 5, NULL),
(126, '6', 5, NULL),
(127, '7', 5, NULL),
(128, '8', 5, NULL),
(129, '9', 5, NULL),
(130, '10', 5, NULL),
(131, '11', 5, NULL),
(132, '12', 5, NULL),
(133, '13', 5, NULL),
(134, '14', 5, NULL),
(135, '15', 5, NULL),
(136, '16', 5, NULL),
(137, '17', 5, NULL),
(138, '18', 5, NULL),
(139, '19', 5, NULL),
(140, '20', 5, NULL),
(141, '21', 5, NULL),
(142, '22', 5, NULL),
(143, '23', 5, NULL),
(144, '24', 5, NULL),
(145, '25', 5, NULL),
(146, '26', 5, NULL),
(147, '27', 5, NULL),
(148, '28', 5, NULL),
(149, '29', 5, NULL),
(150, '30', 5, NULL),
(151, '1', 6, NULL),
(152, '2', 6, NULL),
(153, '3', 6, NULL),
(154, '4', 6, NULL),
(155, '5', 6, NULL),
(156, '6', 6, NULL),
(157, '7', 6, NULL),
(158, '8', 6, NULL),
(159, '9', 6, NULL),
(160, '10', 6, NULL),
(161, '11', 6, NULL),
(162, '12', 6, NULL),
(163, '13', 6, NULL),
(164, '14', 6, NULL),
(165, '15', 6, NULL),
(166, '16', 6, NULL),
(167, '17', 6, NULL),
(168, '18', 6, NULL),
(169, '19', 6, NULL),
(170, '20', 6, NULL),
(171, '21', 6, NULL),
(172, '22', 6, NULL),
(173, '23', 6, NULL),
(174, '24', 6, NULL),
(175, '25', 6, NULL),
(176, '26', 6, NULL),
(177, '27', 6, NULL),
(178, '28', 6, NULL),
(179, '29', 6, NULL),
(180, '30', 6, NULL),
(181, '1', 7, NULL),
(182, '2', 7, NULL),
(183, '3', 7, NULL),
(184, '4', 7, NULL),
(185, '5', 7, NULL),
(186, '6', 7, NULL),
(187, '7', 7, NULL),
(188, '8', 7, NULL),
(189, '9', 7, NULL),
(190, '10', 7, NULL),
(191, '11', 7, NULL),
(192, '12', 7, NULL),
(193, '13', 7, NULL),
(194, '14', 7, NULL),
(195, '15', 7, NULL),
(196, '16', 7, NULL),
(197, '17', 7, NULL),
(198, '18', 7, NULL),
(199, '19', 7, NULL),
(200, '20', 7, NULL),
(201, '21', 7, NULL),
(202, '22', 7, NULL),
(203, '23', 7, NULL),
(204, '24', 7, NULL),
(205, '25', 7, NULL),
(206, '26', 7, NULL),
(207, '27', 7, NULL),
(208, '28', 7, NULL),
(209, '29', 7, NULL),
(210, '30', 7, NULL),
(211, '1', 8, NULL),
(212, '2', 8, NULL),
(213, '3', 8, NULL),
(214, '4', 8, NULL),
(215, '5', 8, NULL),
(216, '6', 8, NULL),
(217, '7', 8, NULL),
(218, '8', 8, NULL),
(219, '9', 8, NULL),
(220, '10', 8, NULL),
(221, '11', 8, NULL),
(222, '12', 8, NULL),
(223, '13', 8, NULL),
(224, '14', 8, NULL),
(225, '15', 8, NULL),
(226, '16', 8, NULL),
(227, '17', 8, NULL),
(228, '18', 8, NULL),
(229, '19', 8, NULL),
(230, '20', 8, NULL),
(231, '21', 8, NULL),
(232, '22', 8, NULL),
(233, '23', 8, NULL),
(234, '24', 8, NULL),
(235, '25', 8, NULL),
(236, '26', 8, NULL),
(237, '27', 8, NULL),
(238, '28', 8, NULL),
(239, '29', 8, NULL),
(240, '30', 8, NULL),
(241, '1', 9, NULL),
(242, '2', 9, NULL),
(243, '3', 9, NULL),
(244, '4', 9, NULL),
(245, '5', 9, NULL),
(246, '6', 9, NULL),
(247, '7', 9, NULL),
(248, '8', 9, NULL),
(249, '9', 9, NULL),
(250, '10', 9, NULL),
(251, '11', 9, NULL),
(252, '12', 9, NULL),
(253, '13', 9, NULL),
(254, '14', 9, NULL),
(255, '15', 9, NULL),
(256, '16', 9, NULL),
(257, '17', 9, NULL),
(258, '18', 9, NULL),
(259, '19', 9, NULL),
(260, '20', 9, NULL),
(261, '21', 9, NULL),
(262, '22', 9, NULL),
(263, '23', 9, NULL),
(264, '24', 9, NULL),
(265, '25', 9, NULL),
(266, '26', 9, NULL),
(267, '27', 9, NULL),
(268, '28', 9, NULL),
(269, '29', 9, NULL),
(270, '30', 9, NULL),
(271, '1', 10, NULL),
(272, '2', 10, NULL),
(273, '3', 10, NULL),
(274, '4', 10, NULL),
(275, '5', 10, NULL),
(276, '6', 10, NULL),
(277, '7', 10, NULL),
(278, '8', 10, NULL),
(279, '9', 10, NULL),
(280, '10', 10, NULL),
(281, '11', 10, NULL),
(282, '12', 10, NULL),
(283, '13', 10, NULL),
(284, '14', 10, NULL),
(285, '15', 10, NULL),
(286, '16', 10, NULL),
(287, '17', 10, NULL),
(288, '18', 10, NULL),
(289, '19', 10, NULL),
(290, '20', 10, NULL),
(291, '21', 10, NULL),
(292, '22', 10, NULL),
(293, '23', 10, NULL),
(294, '24', 10, NULL),
(295, '25', 10, NULL),
(296, '26', 10, NULL),
(297, '27', 10, NULL),
(298, '28', 10, NULL),
(299, '29', 10, NULL),
(300, '30', 10, NULL),
(301, '1', 11, NULL),
(302, '2', 11, NULL),
(303, '3', 11, NULL),
(304, '4', 11, NULL),
(305, '5', 11, NULL),
(306, '6', 11, NULL),
(307, '7', 11, NULL),
(308, '8', 11, NULL),
(309, '9', 11, NULL),
(310, '10', 11, NULL),
(311, '11', 11, NULL),
(312, '12', 11, NULL),
(313, '13', 11, NULL),
(314, '14', 11, NULL),
(315, '15', 11, NULL),
(316, '16', 11, NULL),
(317, '17', 11, NULL),
(318, '18', 11, NULL),
(319, '19', 11, NULL),
(320, '20', 11, NULL),
(321, '21', 11, NULL),
(322, '22', 11, NULL),
(323, '23', 11, NULL),
(324, '24', 11, NULL),
(325, '25', 11, NULL),
(326, '26', 11, NULL),
(327, '27', 11, NULL),
(328, '28', 11, NULL),
(329, '29', 11, NULL),
(330, '30', 11, NULL),
(331, '1', 12, NULL),
(332, '2', 12, NULL),
(333, '3', 12, NULL),
(334, '4', 12, NULL),
(335, '5', 12, NULL),
(336, '6', 12, NULL),
(337, '7', 12, NULL),
(338, '8', 12, NULL),
(339, '9', 12, NULL),
(340, '10', 12, NULL),
(341, '11', 12, NULL),
(342, '12', 12, NULL),
(343, '13', 12, NULL),
(344, '14', 12, NULL),
(345, '15', 12, NULL),
(346, '16', 12, NULL),
(347, '17', 12, NULL),
(348, '18', 12, NULL),
(349, '19', 12, NULL),
(350, '20', 12, NULL),
(351, '21', 12, NULL),
(352, '22', 12, NULL),
(353, '23', 12, NULL),
(354, '24', 12, NULL),
(355, '25', 12, NULL),
(356, '26', 12, NULL),
(357, '27', 12, NULL),
(358, '28', 12, NULL),
(359, '29', 12, NULL),
(360, '30', 12, NULL),
(361, '1', 13, NULL),
(362, '2', 13, NULL),
(363, '3', 13, NULL),
(364, '4', 13, NULL),
(365, '5', 13, NULL),
(366, '6', 13, NULL),
(367, '7', 13, NULL),
(368, '8', 13, NULL),
(369, '9', 13, NULL),
(370, '10', 13, NULL),
(371, '11', 13, NULL),
(372, '12', 13, NULL),
(373, '13', 13, NULL),
(374, '14', 13, NULL),
(375, '15', 13, NULL),
(376, '16', 13, NULL),
(377, '17', 13, NULL),
(378, '18', 13, NULL),
(379, '19', 13, NULL),
(380, '20', 13, NULL),
(381, '21', 13, NULL),
(382, '22', 13, NULL),
(383, '23', 13, NULL),
(384, '24', 13, NULL),
(385, '25', 13, NULL),
(386, '26', 13, NULL),
(387, '27', 13, NULL),
(388, '28', 13, NULL),
(389, '29', 13, NULL),
(390, '30', 13, NULL),
(391, '1', 14, NULL),
(392, '2', 14, NULL),
(393, '3', 14, NULL),
(394, '4', 14, NULL),
(395, '5', 14, NULL),
(396, '6', 14, NULL),
(397, '7', 14, NULL),
(398, '8', 14, NULL),
(399, '9', 14, NULL),
(400, '10', 14, NULL),
(401, '11', 14, NULL),
(402, '12', 14, NULL),
(403, '13', 14, NULL),
(404, '14', 14, NULL),
(405, '15', 14, NULL),
(406, '16', 14, NULL),
(407, '17', 14, NULL),
(408, '18', 14, NULL),
(409, '19', 14, NULL),
(410, '20', 14, NULL),
(411, '21', 14, NULL),
(412, '22', 14, NULL),
(413, '23', 14, NULL),
(414, '24', 14, NULL),
(415, '25', 14, NULL),
(416, '26', 14, NULL),
(417, '27', 14, NULL),
(418, '28', 14, NULL),
(419, '29', 14, NULL),
(420, '30', 14, NULL),
(421, '1', 15, NULL),
(422, '2', 15, NULL),
(423, '3', 15, NULL),
(424, '4', 15, NULL),
(425, '5', 15, NULL),
(426, '6', 15, NULL),
(427, '7', 15, NULL),
(428, '8', 15, NULL),
(429, '9', 15, NULL),
(430, '10', 15, NULL),
(431, '11', 15, NULL),
(432, '12', 15, NULL),
(433, '13', 15, NULL),
(434, '14', 15, NULL),
(435, '15', 15, NULL),
(436, '16', 15, NULL),
(437, '17', 15, NULL),
(438, '18', 15, NULL),
(439, '19', 15, NULL),
(440, '20', 15, NULL),
(441, '21', 15, NULL),
(442, '22', 15, NULL),
(443, '23', 15, NULL),
(444, '24', 15, NULL),
(445, '25', 15, NULL),
(446, '26', 15, NULL),
(447, '27', 15, NULL),
(448, '28', 15, NULL),
(449, '29', 15, NULL),
(450, '30', 15, NULL),
(451, '1', 16, NULL),
(452, '2', 16, NULL),
(453, '3', 16, NULL),
(454, '4', 16, NULL),
(455, '5', 16, NULL),
(456, '6', 16, NULL),
(457, '7', 16, NULL),
(458, '8', 16, NULL),
(459, '9', 16, NULL),
(460, '10', 16, NULL),
(461, '11', 16, NULL),
(462, '12', 16, NULL),
(463, '13', 16, NULL),
(464, '14', 16, NULL),
(465, '15', 16, NULL),
(466, '16', 16, NULL),
(467, '17', 16, NULL),
(468, '18', 16, NULL),
(469, '19', 16, NULL),
(470, '20', 16, NULL),
(471, '21', 16, NULL),
(472, '22', 16, NULL),
(473, '23', 16, NULL),
(474, '24', 16, NULL),
(475, '25', 16, NULL),
(476, '26', 16, NULL),
(477, '27', 16, NULL),
(478, '28', 16, NULL),
(479, '29', 16, NULL),
(480, '30', 16, NULL),
(481, '1', 17, NULL),
(482, '2', 17, NULL),
(483, '3', 17, NULL),
(484, '4', 17, NULL),
(485, '5', 17, NULL),
(486, '6', 17, NULL),
(487, '7', 17, NULL),
(488, '8', 17, NULL),
(489, '9', 17, NULL),
(490, '10', 17, NULL),
(491, '11', 17, NULL),
(492, '12', 17, NULL),
(493, '13', 17, NULL),
(494, '14', 17, NULL),
(495, '15', 17, NULL),
(496, '16', 17, NULL),
(497, '17', 17, NULL),
(498, '18', 17, NULL),
(499, '19', 17, NULL),
(500, '20', 17, NULL),
(501, '21', 17, NULL),
(502, '22', 17, NULL),
(503, '23', 17, NULL),
(504, '24', 17, NULL),
(505, '25', 17, NULL),
(506, '26', 17, NULL),
(507, '27', 17, NULL),
(508, '28', 17, NULL),
(509, '29', 17, NULL),
(510, '30', 17, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lichchieu`
--
ALTER TABLE `lichchieu`
  ADD PRIMARY KEY (`MaLichChieu`);

--
-- Indexes for table `phim`
--
ALTER TABLE `phim`
  ADD PRIMARY KEY (`MaPhim`);

--
-- Indexes for table `tai_khoan`
--
ALTER TABLE `tai_khoan`
  ADD PRIMARY KEY (`MaKhachHang`),
  ADD UNIQUE KEY `Email` (`MaKhachHang`);

--
-- Indexes for table `ve`
--
ALTER TABLE `ve`
  ADD PRIMARY KEY (`MaVe`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tai_khoan`
--
ALTER TABLE `tai_khoan`
  MODIFY `MaKhachHang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `ve`
--
ALTER TABLE `ve`
  MODIFY `MaVe` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=511;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
