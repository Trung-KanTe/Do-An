<?php
	include_once '../giao_dien/cau_hinh.php';
?>
<?php
	$list_check = array(
		1 => "9:00 - 11:00",
		2 => "11:00 - 13:00",
		3 => "13:00 - 15:00",
		4 => "15:00 - 17:00",
		5 => "17:00 - 19:00",
	);
	$list_TheLoai = array(
		1 => "Hành động",
		2 => "Tâm lý",
		3 => "Hài hước",
		4 => "Khoa học viễn tưởng",
		5 => "Kịch tính",
		6 => "Tài liệu",
		7 => "Hoạt hình",
		8 => "Kinh dị",
		9 => "Lãng mạn",
		10 => "Võ thuật",
	);
?>
<!DOCTYPE HTML>
<html>
	<body>	
		<?php
		    if ($_FILES["taptin1"]["error"] > 0)
			{
				echo "Lỗi: " . $_FILES["taptin1"]["error"] . "<br/>";
			}
			else
			{
				$MaPhim = $_POST['txt_MaPhim'];
				$TenPhim = $_POST['txt_TenPhim'];
				$TheLoai = "";
				if (isset($_POST["theloai"])) {
						// Lặp qua mảng của checkbox để lưu trữ vào cơ sở dữ liệu
						$theloaiPhim = $_POST["theloai"];	
						foreach ($theloaiPhim as $value) {	
							$TheLoai = $TheLoai . $list_TheLoai[$value] . " ";
						}
				}
				$FileAnh = $_FILES['taptin1']['name'];
				$GiaVe = $_POST['gia'];
				$autoMaLichChieu = isset($_SESSION["AutoMaLichChieu"]) ? $_SESSION["AutoMaLichChieu"] : 1;
				if ($_SERVER["REQUEST_METHOD"] == "POST") { 
					if (isset($_POST["thoigian"])) {
						$lichChieu = $_POST["thoigian"];
				
						foreach ($lichChieu as $value) {
							$MaLichChieu = $autoMaLichChieu;
							$sql_phim = "INSERT INTO lichchieu (MaLichChieu, LichChieu, MaPhim) VALUES ('$MaLichChieu', '$list_check[$value]', '$MaPhim')";
				
							if ($connect->query($sql_phim) === TRUE) {
								for ($i = 1; $i <= 30; $i++) {
									$sql_ve = "INSERT INTO ve (Tenve, MaLichChieu) VALUES ('$i', '$MaLichChieu')";
									$connect->query($sql_ve);
								}
								$autoMaLichChieu++;
							} else {
								// Handle SQL error
								echo "Lỗi: " . $connect->error;
								$_SESSION["Upload_ThanhCong"] = "Phim chưa được tải lên";
							}
						}
				
						// Redirect after completing all operations in the loop
						header("Location: giao_dien_admin.php?action=../admin/phim");
						$_SESSION["Upload_ThanhCong"] = "Phim đã được tải lên";
					}
				
					// Save the updated value into $_SESSION
					$_SESSION["AutoMaLichChieu"] = $autoMaLichChieu;
				
					// Close the connection
				}
				if (file_exists("../upload/" . $_FILES["taptin1"]["name"]))
				{
					session_start();
					header("Location: giao_dien_admin.php?action=../admin/phim");
					$_SESSION["Upload_ThanhCong"] = "Phim chưa được tải lên";
				}
				else
				{
					move_uploaded_file($_FILES["taptin1"]["tmp_name"], "../upload/" . $_FILES["taptin1"]["name"]);
					$sql = "insert into `phim` (`MaPhim`,`TenPhim`, `TheLoai`, `HinhAnh`, `GiaVe`)
					VALUES ('$MaPhim', '$TenPhim', '$TheLoai', '$FileAnh', '$GiaVe')";				
					if ($connect->query($sql) === TRUE){
						header("Location: giao_dien_admin.php?action=../admin/phim");
						$_SESSION["Upload_ThanhCong"] = "Phim đã được tải lên";
					} else {
						echo "Lỗi: ";
						header("Location: giao_dien_admin.php?action=../admin/phim");
						$_SESSION["Upload_ThanhCong"] = "Phim chưa được tải lên";

					}
				}	
				$connect->close();
			}
		?>
	</body>
</html>