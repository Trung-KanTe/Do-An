<!DOCTYPE html>
<html lang="en">
<style>
        td{
            text-align: center;
            font-size: 18px;
        }
		b{
			font-size: 25px;
		}
    </style>
<body>
    <?php
        include_once '../giao_dien/cau_hinh.php';
             $sql_kiemtra = "SELECT * FROM tai_khoan ";				
             
             $danh_sach = $connect->query($sql_kiemtra);
             //Nếu kết quả kết nối không được thì xuất báo lỗi và thoát
             if (!$danh_sach) {
                 die("Không thể thực hiện câu lệnh SQL: " . $connect->connect_error);
                 exit();
             }
    ?>
    <table align="center" class="List" border="2" width="1180" cellpadding="3">
		<tr>
			<td colspan="8" class="tieude1">
				<b>Danh sách người dùng đã đăng ký </b> 
			</td>
		</tr>	
		<tr>
			<th>Số thứ tự</th>
			<th>Họ và tên</th>
			<th>Số điện thoại</th>
			<th>Email</th>
			<th>Tên tài khoản</th>
		</tr>

        <?php   
            $stt = 1;
            while ($row = $danh_sach->fetch_array(MYSQLI_ASSOC)){
				echo "<tr>";
				    echo "<td>" . $stt . "</td>";
					echo "<td>" . $row['HoNguoiDung'] ." " .$row['TenNguoiDung']. "</td>";
					echo "<td>" . $row['SoDienThoai'] . "</td>";
					echo "<td>" . $row['Email'] . "</td>";
					echo "<td>" . $row['TenTaiKhoan'] . "</td>";     
				echo "</tr>";
				$stt++;
            }
        ?>
    </table>
</body>
</html>