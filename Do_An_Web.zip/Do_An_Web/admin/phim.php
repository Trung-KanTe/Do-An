<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        td{
            text-align: center;
            font-size: 16px;
        }
        b{
			font-size: 25px;
		}
    </style>
</head>
<body>
    <?php
        include_once '../giao_dien/cau_hinh.php';
             $sql_kiemtra = "SELECT * FROM phim ";				
             
             $danh_sach = $connect->query($sql_kiemtra);
             //Nếu kết quả kết nối không được thì xuất báo lỗi và thoát
             if (!$danh_sach) {
                 die("Không thể thực hiện câu lệnh SQL: " . $connect->connect_error);
                 exit();
             }
    ?>
        <table align="center" class="List" border="2" width="1180" cellpadding="1">
            <tr>
                <td colspan="8" class="tieude1">
                    <b>Danh sách phim đang được đặt vé</b> 
                </td>
            </tr>	
            <tr>
                <th>Số thứ tự</th>
                <th>Mã phim</th>
                <th>Tên phim</th>
                <th>Thể loại</th>
                <th>Giá vé</th>
                <th>Hình ảnh</th>

            </tr>

            <?php   
                $stt = 1;
                while ($row = $danh_sach->fetch_array(MYSQLI_ASSOC)){
                    echo "<tr>";
                        echo "<td>" . $stt . "</td>";
                        echo "<td>" . $row['MaPhim'] ."</td>";
                        echo "<td>" . $row['TenPhim'] . "</td>";
                        echo "<td>" . $row['TheLoai'] . "</td>";
                        echo "<td>" . $row['GiaVe'] . " VND</td>"; 
                        echo "<td><img src='../upload/" . $row['HinhAnh'] . "' width= '80px'></td>"; 
                    echo "</tr>";
                    $stt++;
                } 
            ?>
                <tr>
                <td colspan="8" class="tieude1">
                    <a href="giao_dien_admin.php?action=../admin/upload_phim">Thêm phim</a>
                </td>
            </tr>
        </table>
</body>
</html>