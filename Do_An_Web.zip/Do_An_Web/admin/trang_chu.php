<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="trang_chu">
        <div class="the_ChuyenTrang" id="link_QuanLiNguoiDung">
            <p>Người dùng</p>               
        </div>
        <div class="the_ChuyenTrang" id="link_QuanLiPhim">
            <p>Phim</p>
        </div>
    </div>
</body>
</html>