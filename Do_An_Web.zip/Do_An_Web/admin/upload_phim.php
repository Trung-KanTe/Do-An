
<html>
	<head>
		<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" href="../css/upload_phim.css">
	</head>
	<body>
		<div class="trang_chu">
		<form action="../admin/upload_phim_submit.php" method="post" onsubmit="return submit_form();" enctype="multipart/form-data">
			<label for="">Chọn tập tin: </label>
			<input type="file" name="taptin1"/><br/>
			<label for="">Mã phim: </label>
			<input class="input" type="text" name="txt_MaPhim" placeholder="Mã Phim">
			<br>
			<label for="">Tên phim: </label>
            <input class="input" type="text" name="txt_TenPhim" placeholder="Tên Phim">
			<br>
			<div class="TheLoai">
				<label for="">Thể loại:</label><br>
				<input class="check_TheLoai" type="checkbox" name="theloai[]" value="1">Hành động
				<input class="check_TheLoai" type="checkbox" name="theloai[]" value="2">Tâm lý
				<input class="check_TheLoai" type="checkbox" name="theloai[]" value="3">Hài hước
				<input class="check_TheLoai" type="checkbox" name="theloai[]" value="4">Khoa học viễn tưởng
				<input class="check_TheLoai" type="checkbox" name="theloai[]" value="5">Kịch tính
				<input class="check_TheLoai" type="checkbox" name="theloai[]" value="6">Tài liệu
				<input class="check_TheLoai" type="checkbox" name="theloai[]" value="7">Hoạt hình
				<input class="check_TheLoai" type="checkbox" name="theloai[]" value="8">Kinh dị
				<input class="check_TheLoai" type="checkbox" name="theloai[]" value="9">Lãng mạn
				<input class="check_TheLoai" type="checkbox" name="theloai[]" value="10">Võ Thuật
			</div>
			<div class="thoi_gian_chieu">
				<label for="">Thời gian chiếu:</label><br>
				<input class="check_ThoiGianChieu" type="checkbox" name="thoigian[]" value="1" >9:00 - 11:00
				<input class="check_ThoiGianChieu" type="checkbox" name="thoigian[]" value="2" >11:00 - 13:00
				<input class="check_ThoiGianChieu" type="checkbox" name="thoigian[]" value="3" >13:00 - 15:00
				<input class="check_ThoiGianChieu" type="checkbox" name="thoigian[]" value="4" >15:00 - 17:00
				<input class="check_ThoiGianChieu" type="checkbox" name="thoigian[]" value="5" >17:00 - 19:00
	    	</div>
			<div class="gia_ve">
				<label for="">Giá vé:</label><br>
				<input type="radio" checked="true" name="gia" value="100000">100.000 VND
				<input type="radio" name="gia" value="150000">150.000 VND
			</div>
			<button type="submit" onclick="submit_form()" name="submit">Hoàn Thành</button>
		</form>
		</div>
	<script>
		
		function submit_form(){
			var checkThoiGianChieu = document.getElementsByClassName('check_ThoiGianChieu');
			var check_TheLoai = document.getElementsByClassName('check_TheLoai');
			var input_MaPhim = document.getElementsByClassName('input')[0];
			var input_TenPhim = document.getElementsByClassName('input')[1];
			var check_thoigian = false;
			var check_TheLoai = false;
			for (let i = 0; i < checkThoiGianChieu.length; i++){
				if (checkThoiGianChieu[i].checked === true){
					check_thoigian = true;
					break;
				}
			}

			for (let i = 0; i < checkTheLoai.length; i++){
				if (checkTheLoai[i].checked === true){
					check_thoigian = true;
					break;
				}
			}
			if (check_thoigian === false){
				alert("Vui lòng check thời gian chiếu");
				return false;
			}
			if (check_TheLoai === false){
				alert("Vui lòng check thể loại");
				return false;
			}
			if (input_TenPhim.value == "" || input_MaPhim == ""){
				alert("Vui lòng nhập thông tin");
				return false;
			}
			return true;
		}
	</script>
	</body>
</html>