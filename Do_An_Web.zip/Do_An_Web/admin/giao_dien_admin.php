<?php
    include_once '../giao_dien/cau_hinh.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/mau_va_kieuchu.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" integrity="sha512-Avb2QiuDEEvB4bZJYdft2mNjVShBftLdPG8FJ0V7irTLQ8Uo0qcPxh4Plq7G5tGm0rU+1SPhVotteLpBERwTkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../css/giao_dien_admin.css">
</head>
<body>
    <div class="nemu_doc">
        <div id="link_TrangChu">
            <i class="fa-solid fa-house"></i>
            <p>Trang chủ</p>
        </div>

        <div class="quan_li">
            <p>Quản lí</p>
            <li><a href="giao_dien_admin.php?action=../admin/nguoi_dung">Người dùng </a></li>
            <li><a href="giao_dien_admin.php?action=../admin/phim">Phim</a></li>
        </div>
    </div>
    <div class="thanh_dieu_huong">
        <div class="logo">
            <i class="fa-solid fa-film"></i>
            <p>NghiMovies</p>
        </div>
        <div id="khung_ten" class="dangnhap"> 
            <div class="avatar" >
                <?php
                    if (isset($_SESSION['KiTuTen'])){
                        echo $_SESSION['KiTuTen'];
                    }
                ?>
            </div>
            <div class="ten_nguoi_dung">
                <?php
                    if (isset($_SESSION['HoNguoiDung']) && isset($_SESSION['TenNguoiDung'])){
                        echo $_SESSION['TenNguoiDung']." ". $_SESSION['HoNguoiDung'];
                    }
                ?>
            </div>
            <a class="dang_xuat" href="../giao_dien/index.php?action=dangxuat">Đăng xuất</a>
        </div>
    </div>
    <div class="trang_giua">
        <?php
            $act = isset($_GET['action']) ? $_GET['action'] : "trang_chu";	
            include $act . ".php";
        ?>
    </div>

    <?php
    if (isset($_SESSION['TenNguoiDung'])) {
        echo "
            <script>
                var khung_ten = document.getElementById('khung_ten');
                var khung_dang_nhap = document.getElementById('the_dang_nhap');
                khung_ten.style.display = 'flex';
                khung_dang_nhap.style.display = 'none';
            </script>
        ";
    }else{
        if ($_SESSION['loi_dang_nhap'] === 1){
            echo '
            <script>
                alert("Đăng nhập không thành công");
                document.location.href = "../giao_dien/index.php?action=../nguoi_dung/dangnhap";
            </script>';
        }
        $_SESSION['loi_dang_nhap'] = 0;
    }
    ?>
    <?php
        if (isset($_SESSION['Upload_ThanhCong'])) {
            echo "<script>alert('{$_SESSION['Upload_ThanhCong']}');</script>";
                unset($_SESSION['Upload_ThanhCong']);
        }
    ?>

    <script>
        document.getElementById('link_TrangChu').addEventListener('click', function(){
            document.location.href = 'giao_dien_admin.php?action=../admin/trang_chu';
        });
        document.getElementById('link_QuanLiNguoiDung').addEventListener('click', function(){
            document.location.href = 'giao_dien_admin.php?action=../admin/nguoi_dung';
        });
        document.getElementById('link_QuanLiPhim').addEventListener('click', function(){
            document.location.href = 'giao_dien_admin.php?action=../admin/phim';
        });
    </script>
</body>
</html>