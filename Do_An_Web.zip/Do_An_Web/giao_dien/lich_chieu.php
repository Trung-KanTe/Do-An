<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/lich_chieu.css">
</head>
<body>
    <div id="khung_phim">
    <?php
        include_once '../giao_dien/cau_hinh.php';

        $sql = "SELECT * FROM phim";
        
        $danh_sach = $connect->query($sql);
        if(!$danh_sach){
			die("Khong the thuc hien cau lenh SQL!!!".$connect->connect_error);
			exit();
		}
        while ($row = $danh_sach->fetch_array(MYSQLI_ASSOC)){
            echo '
            <div class="the_phim">
                <div class="poster">
                    <img src="../image/'.$row["HinhAnh"].'">
                </div>
                <div class="khung_chu">
                    <div class="ten_phim">'.$row["TenPhim"].'</div>';
                    $MaPhim = $row['MaPhim'];
                    $sql_lich_chieu = "SELECT * FROM `lichchieu` WHERE MaPhim = '$MaPhim'";
                    $danh_sach_lich_chieu = $connect->query($sql_lich_chieu);
                    if(!$danh_sach_lich_chieu){
                        die("Khong the thuc hien cau lenh SQL!!!".$connect->connect_error);
                        exit();
                    }
                    while ($row1 = $danh_sach_lich_chieu->fetch_array((MYSQLI_ASSOC))){
                        echo '<a href="../giao_dien/index.php?action=ve&id='.$row1["MaLichChieu"].'">'.$row1["LichChieu"].'</a>';
                    }


            echo'
                </div>
            </div>
            ';
        }
    ?>
    </div>
    
</body>

</html>
