<?php
	// Hủy SESSION
	unset($_SESSION['TenNguoiDung']);
	// Chuyển hướng về trang index.php
	header("Location: ../giao_dien/index.php");
?>