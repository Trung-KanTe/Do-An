<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="footer">
        <p>Liên hệ: Võ Thanh Phong- <i>thanhphong2705@gmail.com.</i></p>
        <div class="luot_truy cap">
            <div>
                <i class="fa-solid fa-signal"></i>
                <p>Đang truy cập: 102.</p>
            </div>
            <div>
                <i class="fa-solid fa-user"></i>
                <p>Số lượt truy cập: 6789.</p>
            </div>
           
        </div>

    </div>
</body>
</html>