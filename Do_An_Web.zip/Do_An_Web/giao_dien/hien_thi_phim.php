<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/khung_phim.css">
</head>
<body>
    
    <div id="khung_phim">
        <?php
            include_once '../giao_dien/cau_hinh.php';

            $sql = "SELECT * FROM phim";
            
            $danh_sach = $connect->query($sql);
            if(!$danh_sach){
                die("Khong the thuc hien cau lenh SQL!!!".$connect->connect_error);
                exit();
            }
            $stt = 0;
            while ($row = $danh_sach->fetch_array(MYSQLI_ASSOC)){
                echo '
                <div class="the_phim" id="the_phim_'.$stt.'">
                    <div class="poster">
                        <img src="../image/'.$row["HinhAnh"].'">
                    </div>
                    <div class="khung_chu">
                        <div class="ten_phim">'.$row["TenPhim"].'</div>
                        <div class="the_loai">Thể loại: <br>'.$row["TheLoai"].'</div>
                        <hr>
                        <div class="dat_ve"><a href="../giao_dien/index.php?action=ve_lich_chieu&id='.$row["MaPhim"].'">Đặt vé</a></div>';
                echo'
                    </div>
                </div>
            ';
            
            if ($stt == 3)
                $stt = 0;
            else
                $stt++;
            }
        ?>
    </div>
</body>

</html>
