<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        .khung_phim, .khung_mua_ve{
            width: 100%;
            display: flex;
            background-color: var(--mau_phim_1);
            justify-content: center;

        }
        .khung_mua_ve{
            background-color: inherit;
            flex-wrap: wrap;
            padding: 0px 20%;
            margin: auto;
            padding-top: 40px;
        }
        .ten_phim, .lich_chieu{
            font-size: 30px;
            margin: 20px;
        }
        .dat_ve{
            margin-top: 20px;
            width: 15%;
            background-color: #FFFF33;
            padding: 20px 0px;
            border: var(--vien);
            border-radius: 20px;
            cursor: pointer;
        }
        input{
            width: 50%;
            font-size: 20px;
            
        }
        th, td{
            font-size: 22px;
            padding: 10px 0px;

        }

    </style>
</head>
<body>

    <div class="khung_phim">
    <?php
        include_once '../giao_dien/cau_hinh.php';
        $bien = $_GET['id'];
        $sql = "SELECT * FROM phim, lichchieu where phim.MaPhim = lichchieu.MaPhim AND lichchieu.MaLichChieu = '$bien'";
        $danhsach = $connect->query($sql);	
        $row = $danhsach->fetch_array(MYSQLI_ASSOC);
        echo '<div class="ten_phim">Tên phim: <br>'.$row["TenPhim"].'</div>';
        echo '<div class="lich_chieu">Thời gian chiếu: <br>'.$row["LichChieu"].'</div>';
    ?>
    </div>
    <br>
    <div class="khung_mua_ve">
        
        <table align="center" border="2" width="900%" cellpadding="3">
            <tr>
                <th >Số lượng</th>
                <th>Vé</th>
                <th>Tổng tiền</th>
            </tr>
            <tr align="center"> 
                <td><input type="number" id="so_luong" value="1" min="1"></td>
                <td id="gia_ve"><?php echo $row["GiaVe"];?></td>
                <td id="tong">100000 VND</td>
            </tr>
        </table>
        <button class="dat_ve" onclick="xac_nhan()" >Đặt vé</button>

    </div>
    <script>
        var so_luong = document.getElementById('so_luong');
        
        
        if (so_luong){
            so_luong.addEventListener('input', function(){
                var tong = so_luong.value * document.getElementById('gia_ve').textContent;
                document.getElementById('tong').textContent = tong + " VND";
            });
        }

        function xac_nhan(){
            alert("Mua vé thành công");
            document.location.href = "../giao_dien/index.php";
        }
    </script>
    <?php


    ?>
</body>
</html>