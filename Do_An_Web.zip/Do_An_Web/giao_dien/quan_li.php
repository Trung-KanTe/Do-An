<?php
session_start();
ob_start();
?>
<!DOCTYPE html>
<html>

<body>
	<?php
	if (isset($_SESSION['QuyenHan']) && $_SESSION['QuyenHan'] == 1) {
		Header("Location:../giao_dien/index.php");
	} else if (isset($_SESSION['QuyenHan']) && $_SESSION['QuyenHan'] == 2) {
        Header("Location:../admin/giao_dien_admin.php");
	}
	?>
</body>

</html>