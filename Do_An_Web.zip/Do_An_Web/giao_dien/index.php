<?php
	include_once "../giao_dien/cau_hinh.php";		
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/giao_dien_chinh.css">
    <link rel="stylesheet" href="../css/mau_va_kieuchu.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" integrity="sha512-Avb2QiuDEEvB4bZJYdft2mNjVShBftLdPG8FJ0V7irTLQ8Uo0qcPxh4Plq7G5tGm0rU+1SPhVotteLpBERwTkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Web đặt vé xem phim</title>
    
</head>
<body>
    <div class="nen_tong">
        <div>
            <?php
                include '../giao_dien/thanh_dieu_huong.php';
            ?>
        </div>

        <div class="trang_giua">
            <?php
                $act = isset($_GET['action']) ? $_GET['action'] : "home";	
                include $act . ".php";
            ?>
        </div>
        <div>
            <?php
                include '../giao_dien/footer.php';
            ?>
        </div>
        
    </div>
    <?php
        // Kiểm tra xem có thông báo thành công trong Session hay không
        if (isset($_SESSION['dangky_thanhcong'])) {
            echo "<script>alert('{$_SESSION['dangky_thanhcong']}');</script>";
            // Xóa thông báo thành công khỏi Session để không hiển thị lại
            unset($_SESSION['dangky_thanhcong']);
        }

        if (isset($_SESSION['TenNguoiDung'])) {
            echo "
                <script>
                    var khung_ten = document.getElementById('khung_ten');
                    var khung_dang_nhap = document.getElementById('the_dang_nhap');
                    khung_ten.style.display = 'flex';
                    khung_dang_nhap.style.display = 'none';
                </script>
            ";
        }else{
            if ($_SESSION['loi_dang_nhap'] === 1){
                echo '
                <script>
                    alert("Đăng nhập không thành công");
                    document.location.href = "../giao_dien/index.php?action=../nguoi_dung/dangnhap";
                </script>';
            }
            $_SESSION['loi_dang_nhap'] = 0;
        }
    ?>
    <script>
       
    </script>
</body>
</html>