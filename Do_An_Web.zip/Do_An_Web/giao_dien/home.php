<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="quang_cao">
        <img src="../image/banner.jpg" alt="">
        <div class="lua_chon">
            <p>MUA VÉ ONLINE</p>     
        </div>
        </div>
        <div class="nen_phim">
            <?php
               include "../giao_dien/hien_thi_phim.php";
            ?>
        </div>
</body>
</html>