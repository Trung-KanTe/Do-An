<?php
    include_once '../giao_dien/cau_hinh.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/giao_dien_chinh.css">
    <link rel="stylesheet" href="../css/mau_va_kieuchu.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" integrity="sha512-Avb2QiuDEEvB4bZJYdft2mNjVShBftLdPG8FJ0V7irTLQ8Uo0qcPxh4Plq7G5tGm0rU+1SPhVotteLpBERwTkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <div class="thanh_dieu_huong">
        <div class="thanh_tim_kiem">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="text" placeholder="Tìm kiếm">
        </div>
        <div class="logo">
            <i class="fa-solid fa-film"></i>
            <p>NghiMovies</p>
        </div>
        <div class="dieu_huong">
            <ul>
                <li id="link_Home">PHIM</li>
                <li id="link_LichChieu">LỊCH CHIẾU</li>
            </ul>
        </div>
        <div id="the_dang_nhap" class="dangnhap">
            <a class="nut_dang_ky_dang_nhap" id="btn_DangKy" href="index.php?action=../nguoi_dung/dangky">Đăng ký</a>
            <a class="nut_dang_ky_dang_nhap" id="btn_DangNhap" href="index.php?action=../nguoi_dung/dangnhap">Đăng nhập</a>
        </div> 
        <div id="khung_ten" class="dangnhap"> 
            <div class="avatar" >
                <?php
                    if (isset($_SESSION['KiTuTen'])){
                        echo $_SESSION['KiTuTen'];
                    }
                ?>
               
            </div>
            <div class="ten_nguoi_dung">
                <?php
                    if (isset($_SESSION['HoNguoiDung']) && isset($_SESSION['TenNguoiDung'])){
                        echo $_SESSION['TenNguoiDung']." ". $_SESSION['HoNguoiDung'];
                    }
                ?>
            </div>
            <a class="dang_xuat" href="../giao_dien/index.php?action=dangxuat">Đăng xuất</a>
        </div>
    </div>
    <script>
         document.getElementById('link_Home').addEventListener('click', function(){
            document.location.href = '../giao_dien/index.php?action=../giao_dien/home';
        });
        document.getElementById('link_LichChieu').addEventListener('click', function(){
            document.location.href = '../giao_dien/index.php?action=../giao_dien/lich_chieu';
        });
        function dang_xuat(){
            alert("1");
        }
      

    </script>
</body>
</html>