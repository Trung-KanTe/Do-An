<?php
	session_start();	
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "quan_li_dat_ve";			
	$connect = new mysqli($servername, $username, $password, $dbname);	
	mysqli_set_charset($connect, 'UTF8');
	if ($connect->connect_error) {
	    die("Không kết nối :" . $conn->connect_error);
	    exit();
	}	
?>