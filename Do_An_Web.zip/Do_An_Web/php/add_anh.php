<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST" name="f" enctype="multipart/form-data">
        <table style="clear:both;margin:100px 250px;padding:10px;font-size:11pt;">            
            <input type="file" name="add_img">
            <input type="submit" name="" id="">        
        </table>        
    </form> 

    <?php
    include "connect.php";
    if (isset($_FILES['add_img'])){
        $fileName = $_FILES['add_img']['name'];
        $sql = "INSERT INTO `hinhanh` (`HINHANH`) VALUES ('$fileName')";
        if ($connect->query($sql) === TRUE){
            Header("Location: xuli_anh.php");
        } else {
            echo "Lỗi: ";
        }
        $conn->close();
    }
       
    ?>
</body>
</html>
