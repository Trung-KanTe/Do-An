<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Dynamic Boxes</title>
    <style>
        body {
            margin: 0;
            padding: 20px;
        }
        #container{
            width: 100%;
            box-sizing: border-box;
            height: max-content;
            border: 2px solid black;
            display: flex;
            flex-wrap: wrap;

        }
        .box {
            width: 200px;
            height: 300px;
            border: 1px solid #2980b9;
            flex-basis: calc(17%);
            margin: 10px;
            overflow: hidden;
        }
        img
        {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

    </style>
</head>
<body>
    <div id="container">
    </div>

    <?php
        include "connect.php";

        $sql = "SELECT * FROM `hinhanh`";
        
        $danh_sach = $connect->query($sql);
        if(!$danh_sach){
			die("Khong the thuc hien cau lenh SQL!!!".$connect->connect_error);
			exit();
		}

        $numberOfBoxes = $danh_sach->num_rows;
        echo '
            <script>
                document.addEventListener("DOMContentLoaded", function() {
                    var numberOfBoxes = ' . $numberOfBoxes . ';
                    var container = document.getElementById("container");

                    // Duyệt qua từng bản ghi trong kết quả truy vấn
                    ';
            while ($row = $danh_sach->fetch_assoc()) {
                echo '
                    var box = document.createElement("div");
                    var img = document.createElement("img");
                    box.className = "box";
                    img.src="../image/'.$row["HINHANH"].'";
                    box.appendChild(img);
                    container.appendChild(box);
                ';
            }
                echo '
            });</script>';
        

    ?>
</body>

</html>
