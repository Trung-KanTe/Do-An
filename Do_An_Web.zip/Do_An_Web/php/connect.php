<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "qlanh";

    $connect = new mysqli($servername, $username, $password, $dbname);

    if ($connect->connect_error){
        die ("Error". $connect->connect_error);
        exit();
    }
?>